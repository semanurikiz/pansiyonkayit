﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace pansiyonkayıt
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection baglanti= new SqlConnection("Data Source=DESKTOP-RGG65VF\\MSSQLSERVER01;Initial Catalog=Lavantapansiyon;Integrated Security=True");
        private void btnGirisYap_Click(object sender, EventArgs e)
        {

            string kullanici =txtKullaniciAdi.Text;
            string sifre = txtSifre.Text;

            baglanti.Open();
            SqlCommand sorgula = new SqlCommand("select * from admin_giris WHERE kullanici=@username AND sifre=@password", baglanti);
            sorgula.Parameters.AddWithValue("@username", txtKullaniciAdi.Text);
            sorgula.Parameters.AddWithValue("@password", txtSifre.Text);
            SqlDataReader oku = sorgula.ExecuteReader();
            if (oku.Read())
            {
                //MessageBox.Show("Giriş Başarılı");
                Form3 frm = new Form3();
                frm.Show();
                this.Hide();

            }
            else
            {
                MessageBox.Show("Kullanıcı adı ya da şifre hatalı!");
            }
            baglanti.Close();

            txtKullaniciAdi.Text = "";
            txtSifre.Text = "";
            txtKullaniciAdi.Focus();
        }
      

            private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
