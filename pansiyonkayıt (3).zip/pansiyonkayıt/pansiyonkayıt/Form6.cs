﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace pansiyonkayıt
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }
        SqlConnection baglanti = new SqlConnection("Data Source=DESKTOP-RGG65VF\\MSSQLSERVER01;Initial Catalog=Lavantapansiyon;Integrated Security=True");
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int personel;
            personel= Convert.ToInt16(textBox1.Text);
            lblmaas.Text = (personel*2000).ToString();
            int sonuc;
            sonuc = Convert.ToInt32(lbltoplam.Text) - (Convert.ToInt16(lblmaas.Text) + Convert.ToInt16(lblgıda.Text) + Convert.ToInt16(lbliçecek.Text) + Convert.ToInt16(lbltemizlik.Text) + Convert.ToInt16(lblelektrik.Text) + Convert.ToInt16(lblsu.Text) + Convert.ToInt16(lblinternet.Text));
            lblsonuc.Text = sonuc.ToString();
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            baglanti.Open();
            SqlCommand komut = new SqlCommand("select sum (ucret) as toplam from musteri_ekle", baglanti);
            SqlDataReader oku = komut.ExecuteReader();
            while (oku.Read())
            {
                lbltoplam.Text = oku["toplam"].ToString();
            }
            baglanti.Close();

            baglanti.Open();
            SqlCommand komut2 = new SqlCommand("select sum (gıda) as toplam1 from stoklar", baglanti);
            SqlDataReader oku2 = komut2.ExecuteReader();
            while (oku2.Read())
            {
                lblgıda.Text = oku2["toplam1"].ToString();
            }
            baglanti.Close();
            baglanti.Open();
            SqlCommand komut3 = new SqlCommand("select sum (içecek) as toplam2 from stoklar", baglanti);
            SqlDataReader oku3 = komut3.ExecuteReader();
            while (oku3.Read())
            {
                lbliçecek.Text = oku3["toplam2"].ToString();
            }
            baglanti.Close();
            baglanti.Open();
            SqlCommand komut4 = new SqlCommand("select sum (temizlik) as toplam3 from stoklar", baglanti);
            SqlDataReader oku4 = komut4.ExecuteReader();
            while (oku4.Read())
            {
                lbltemizlik.Text = oku4["toplam3"].ToString();
            }
            baglanti.Close();
            baglanti.Open();
            SqlCommand komut5 = new SqlCommand("select sum (elektrik) as toplam4 from faturalar", baglanti);
            SqlDataReader oku5 = komut5.ExecuteReader();
            while (oku5.Read())
            {
                lblelektrik.Text = oku5["toplam4"].ToString();
            }
            baglanti.Close();
            baglanti.Open();
            SqlCommand komut6 = new SqlCommand("select sum (su) as toplam5 from faturalar", baglanti);
            SqlDataReader oku6 = komut6.ExecuteReader();
            while (oku6.Read())
            {
                lblsu.Text = oku6["toplam5"].ToString();
            }
            baglanti.Close();
            baglanti.Open();
            SqlCommand komut7 = new SqlCommand("select sum (internet) as toplam6 from faturalar", baglanti);
            SqlDataReader oku7 = komut7.ExecuteReader();
            while (oku7.Read())
            {
                lblinternet.Text = oku7["toplam6"].ToString();
            }
            baglanti.Close();

        }
    }
}
