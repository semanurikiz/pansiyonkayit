﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace pansiyonkayıt
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
        }
        SqlConnection baglanti = new SqlConnection("Data Source=DESKTOP-RGG65VF\\MSSQLSERVER01;Initial Catalog=Lavantapansiyon;Integrated Security=True");
        private void veriler()
        {    
            listView1.Items.Clear();
            baglanti.Open();
            SqlCommand komut = new SqlCommand("select * from stoklar", baglanti);
            SqlDataReader oku = komut.ExecuteReader();
            while (oku.Read())
            {

                ListViewItem ekle = new ListViewItem();
                ekle.Text = oku["gıda"].ToString();
                ekle.SubItems.Add(oku["içecek"].ToString());
                ekle.SubItems.Add(oku["temizlik"].ToString());
                listView1.Items.Add(ekle);
            }
            baglanti.Close();

        }
        private void veriler2()
        {
            listView2.Items.Clear();
            baglanti.Open();
            SqlCommand komut2 = new SqlCommand("select * from faturalar", baglanti);
            SqlDataReader oku2 = komut2.ExecuteReader();
            while (oku2.Read())
            {

                ListViewItem ekle = new ListViewItem();
                ekle.Text = oku2["elektrik"].ToString();
                ekle.SubItems.Add(oku2["su"].ToString());
                ekle.SubItems.Add(oku2["internet"].ToString());
                listView2.Items.Add(ekle);
            }
            baglanti.Close();
        }
        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            SqlCommand komut = new SqlCommand("insert into stoklar (gıda, içecek,temizlik) values (@gıda,@içecek, @temizlik)", baglanti);
            komut.Parameters.AddWithValue("@gıda", textBox1.Text);
            komut.Parameters.AddWithValue("@içecek", textBox2.Text);
            komut.Parameters.AddWithValue("@temizlik", textBox3.Text);
            komut.ExecuteNonQuery();
            baglanti.Close();
            veriler();
            MessageBox.Show("Başarıyla Eklendi!");
        }
      

            private void Form8_Load(object sender, EventArgs e)
        {
            veriler();
            veriler2();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            SqlCommand komut = new SqlCommand("insert into faturalar (elektrik, su,internet) values (@elektrik,@su, @internet)", baglanti);
            komut.Parameters.AddWithValue("@elektrik", textBox6.Text);
            komut.Parameters.AddWithValue("@su", textBox5.Text);
            komut.Parameters.AddWithValue("@internet", textBox4.Text);
            komut.ExecuteNonQuery();
            baglanti.Close();
            veriler2();
            MessageBox.Show("Başarıyla Eklendi!");
        }
    }
}
