﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
namespace pansiyonkayıt
{
    public partial class FrmMüsteriler : Form
    {
        public FrmMüsteriler()
        {
            InitializeComponent();
        }

        SqlConnection baglanti;
        SqlCommand komut;
        SqlDataReader dr;

        private void verilergoster()
        {

            baglanti = new SqlConnection("Data Source=DESKTOP-RGG65VF\\MSSQLSERVER01;Initial Catalog=Lavantapansiyon;Integrated Security=True");
            listView1.Items.Clear();
            baglanti.Open();
            SqlCommand komut = new SqlCommand("select * from musteri_ekle", baglanti);
            SqlDataReader dr = komut.ExecuteReader();
            while (dr.Read())
            {

                ListViewItem ekle = new ListViewItem();
                ekle.Text = dr["müsteriid"].ToString();
                ekle.SubItems.Add(dr["adi"].ToString());
                ekle.SubItems.Add(dr["soyadi"].ToString());
                ekle.SubItems.Add(dr["cinsiyet"].ToString());
                ekle.SubItems.Add(dr["telefon"].ToString());
                ekle.SubItems.Add(dr["mail"].ToString());
                ekle.SubItems.Add(dr["TC"].ToString());
                ekle.SubItems.Add(dr["odano"].ToString());
                ekle.SubItems.Add(dr["ucret"].ToString());
                ekle.SubItems.Add(dr["giristarihi"].ToString());
                ekle.SubItems.Add(dr["cikistarihi"].ToString());
                listView1.Items.Add(ekle);
            }
            baglanti.Close();

        }
        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private bool isOn = false;
        private void BtnGoster_Click(object sender, EventArgs e)
        {

            if (isOn)
            {
                pictureBox2.Image = Properties.Resources.off_button__1_; 
                isOn = false;
            }
            else
            {
                pictureBox2.Image = Properties.Resources.on_button;   
                isOn = true;
            }
            verilergoster();
        }

        private void btnGuncelle_Click(object sender, EventArgs e)
        {
            if (isOn)
            {
                pictureBox4.Image = Properties.Resources.off_button__1_;  
                isOn = false;
            }
            else
            {
                pictureBox4.Image = Properties.Resources.on_button;  
                isOn = true;
            }
            baglanti.Open();
            SqlCommand komut = new SqlCommand("update musteri_ekle set adi=@adi,soyadi=@soyadi,cinsiyet=@cinsiyet,telefon=@telefon,mail=@mail,TC=@TC,odano=@odano,ucret=@ucret,giristarihi=@giristarihi,cikistarihi=@cikistarihi", baglanti);
            komut.Parameters.AddWithValue("@adi", txtAd.Text);
            komut.Parameters.AddWithValue("@soyadi", txtSoyad.Text);
            komut.Parameters.AddWithValue("@cinsiyet", cmbCinsiyet.Text);
            komut.Parameters.AddWithValue("@telefon", mskTelefon.Text);
            komut.Parameters.AddWithValue("@mail", txtMail.Text);
            komut.Parameters.AddWithValue("@TC", txtTcNo.Text);
            komut.Parameters.AddWithValue("@odano", txtOdaNo.Text);
            komut.Parameters.AddWithValue("@ucret", txtUcret.Text);
            komut.Parameters.AddWithValue("@giristarihi", dtpGirisTarihi.Value.Date);
            komut.Parameters.AddWithValue("@cikistarihi", dtpCikisTarihi.Value.Date);
            komut.ExecuteNonQuery();
            baglanti.Close();
            verilergoster();
        }

        private void btnSil_Click(object sender, EventArgs e)
        {
            if (isOn)
            {
                pictureBox5.Image = Properties.Resources.off_button__1_;  
                isOn = false;
            }
            else
            {
                pictureBox5.Image = Properties.Resources.on_button;
                isOn = true;
            }
            if (txtOdaNo.Text == "101")
            {
                baglanti.Open();
                SqlCommand komut = new SqlCommand("Delete from oda101", baglanti);
                komut.ExecuteNonQuery();
                baglanti.Close();
                verilergoster();
            }
            if (txtOdaNo.Text == "102")
            {
                baglanti.Open();
                SqlCommand komut = new SqlCommand("Delete from oda102", baglanti);
                komut.ExecuteNonQuery();
                baglanti.Close();
                verilergoster();
            }
            if (txtOdaNo.Text == "103")
            {
                baglanti.Open();
                SqlCommand komut = new SqlCommand("Delete from oda103", baglanti);
                komut.ExecuteNonQuery();
                baglanti.Close();
                verilergoster();
            }

            if (txtOdaNo.Text == "104")
            {
                baglanti.Open();
                SqlCommand komut = new SqlCommand("Delete from oda104", baglanti);
                komut.ExecuteNonQuery();
                baglanti.Close();
                verilergoster();
            }
            if (txtOdaNo.Text == "105")
            {
                baglanti.Open();
                SqlCommand komut = new SqlCommand("Delete from oda105", baglanti);
                komut.ExecuteNonQuery();
                baglanti.Close();
                verilergoster();
            }

            if (txtOdaNo.Text == "106")
            {
                baglanti.Open();
                SqlCommand komut = new SqlCommand("Delete from oda106", baglanti);
                komut.ExecuteNonQuery();
                baglanti.Close();
                verilergoster();
            }
            if (txtOdaNo.Text == "107")
            {
                baglanti.Open();
                SqlCommand komut = new SqlCommand("Delete from oda107", baglanti);
                komut.ExecuteNonQuery();
                baglanti.Close();
                verilergoster();
            }
            if (txtOdaNo.Text == "108")
            {
                baglanti.Open();
                SqlCommand komut = new SqlCommand("Delete from oda108", baglanti);
                komut.ExecuteNonQuery();
                baglanti.Close();
                verilergoster();
            }
            if (txtOdaNo.Text == "109")
            {
                baglanti.Open();
                SqlCommand komut = new SqlCommand("Delete from oda109", baglanti);
                komut.ExecuteNonQuery();
                baglanti.Close();
                verilergoster();
            }

        }

        private void btnAra_Click(object sender, EventArgs e)
        {
            if (isOn)
            {
                pictureBox6.Image = Properties.Resources.off_button__1_;  
                isOn = false;
            }
            else
            {
                pictureBox6.Image = Properties.Resources.on_button;   
                isOn = true;
            }
            baglanti = new SqlConnection("Data Source=DESKTOP-RGG65VF\\MSSQLSERVER01;Initial Catalog=Lavantapansiyon;Integrated Security=True");
            baglanti.Open();
            SqlCommand komut = new SqlCommand("select * from musteri_ekle where adi Like '%" + txtAd.Text + "%'", baglanti);
            SqlDataReader dr = komut.ExecuteReader();
            while (dr.Read())
            {

                ListViewItem ekle = new ListViewItem();
                ekle.Text = dr["müsteriid"].ToString();
                ekle.SubItems.Add(dr["adi"].ToString());
                ekle.SubItems.Add(dr["soyadi"].ToString());
                ekle.SubItems.Add(dr["cinsiyet"].ToString());
                ekle.SubItems.Add(dr["telefon"].ToString());
                ekle.SubItems.Add(dr["mail"].ToString());
                ekle.SubItems.Add(dr["TC"].ToString());
                ekle.SubItems.Add(dr["odano"].ToString());
                ekle.SubItems.Add(dr["ucret"].ToString());
                ekle.SubItems.Add(dr["giristarihi"].ToString());
                ekle.SubItems.Add(dr["cikistarihi"].ToString());
                listView1.Items.Add(ekle);
            }
          baglanti.Close();
        }


        int id = 0;
        private void listView1_SelectedIndexChanged_1(object sender, EventArgs e)
        {

            id = int.Parse(listView1.SelectedItems[0].SubItems[0].Text);
            txtAd.Text=listView1.SelectedItems[0].SubItems[1].Text;
            txtSoyad.Text=listView1.SelectedItems[0].SubItems[2].Text;
            cmbCinsiyet.Text=listView1.SelectedItems[0].SubItems[3].Text;
            mskTelefon.Text=listView1.SelectedItems[0].SubItems[4].Text;
            txtMail.Text=listView1.SelectedItems[0].SubItems[5].Text;
            txtTcNo.Text=listView1.SelectedItems[0].SubItems[6].Text;
            txtOdaNo.Text=listView1.SelectedItems[0].SubItems[7].Text;
            txtUcret.Text=listView1.SelectedItems[0].SubItems[8].Text;
            dtpGirisTarihi.Text=listView1.SelectedItems[0].SubItems[9].Text;
            dtpCikisTarihi.Text=listView1.SelectedItems[0].SubItems[10].Text;
         

        }

        private void btnTemizle_Click(object sender, EventArgs e)
        {
            if (isOn)
            {
                pictureBox7.Image = Properties.Resources.off_button__1_;
                isOn = false;
            }
            else
            {
                pictureBox7.Image = Properties.Resources.on_button;
                isOn = true;
            }
            txtAd.Clear();
            txtSoyad.Clear();
            mskTelefon.Clear();
            txtMail.Clear();
            txtTcNo.Clear();
            txtOdaNo.Clear();
            txtUcret.Clear();
            dtpGirisTarihi.Text = "";
            dtpCikisTarihi.Text = "";
        }
    }

}
