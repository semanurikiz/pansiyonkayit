﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;

namespace pansiyonkayıt
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
        }
        SqlConnection baglanti = new SqlConnection("Data Source=DESKTOP-RGG65VF\\MSSQLSERVER01;Initial Catalog=Lavantapansiyon;Integrated Security=True");
        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void verilergoster()
        {

  
            listView2.Items.Clear();
            baglanti.Open();
            SqlCommand komut = new SqlCommand("select * from personel", baglanti);
            SqlDataReader dr = komut.ExecuteReader();
            while (dr.Read())
            {

                ListViewItem ekle = new ListViewItem();
                ekle.Text = dr["id"].ToString();
                ekle.SubItems.Add(dr["adi"].ToString());
                ekle.SubItems.Add(dr["soyadi"].ToString());
                ekle.SubItems.Add(dr["telefon"].ToString());
                ekle.SubItems.Add(dr["yetki"].ToString());
                ekle.SubItems.Add(dr["maaş"].ToString());

                listView2.Items.Add(ekle);
            }
            baglanti.Close();

        }

        private void btnKaydet_Click(object sender, EventArgs e)
        {
          

            baglanti.Open();

            SqlCommand kayit = new SqlCommand("insert into personel (adi,soyadi,telefon,yetki,maaş) values(@adi, @soyadi,@telefon,@yetki,@maaş)", baglanti);
            kayit.Parameters.AddWithValue("@adi", textBox10.Text);
            kayit.Parameters.AddWithValue("@soyadi", textBox9.Text);
            kayit.Parameters.AddWithValue("@telefon", maskedTextBox3.Text);
            kayit.Parameters.AddWithValue("@yetki", comboBox3.Text);
            kayit.Parameters.AddWithValue("@maaş", textBox8.Text);
            kayit.ExecuteNonQuery();
            baglanti.Close();
            MessageBox.Show("Personel başarıyla eklendi!");
            textBox10.Clear();
            textBox9.Clear();
            maskedTextBox3.Clear();
            textBox8.Clear();
        }


     



     

        private void button5_Click(object sender, EventArgs e)
        {
            verilergoster();
        }
        int id = 0;
        private void listView2_SelectedIndexChanged(object sender, EventArgs e)
        {
            id = int.Parse(listView2.SelectedItems[0].SubItems[0].Text);
            textBox1.Text = listView2.SelectedItems[0].SubItems[1].Text;
            textBox2.Text = listView2.SelectedItems[0].SubItems[2].Text;
            maskedTextBox1.Text = listView2.SelectedItems[0].SubItems[3].Text;
            comboBox1.Text = listView2.SelectedItems[0].SubItems[4].Text;
            textBox3.Text = listView2.SelectedItems[0].SubItems[5].Text;

        }

        private void button4_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            SqlCommand komut = new SqlCommand("update personel set adi=@adi,soyadi=@soyadi,telefon=@telefon,yetki=@yetki,maaş=@maaş", baglanti);
            komut.Parameters.AddWithValue("@adi", textBox1.Text);
            komut.Parameters.AddWithValue("@soyadi", textBox2.Text);
            komut.Parameters.AddWithValue("@telefon", maskedTextBox1.Text);
            komut.Parameters.AddWithValue("@yetki", comboBox1.Text);
            komut.Parameters.AddWithValue("@maaş",textBox3.Text);
            komut.ExecuteNonQuery();
            baglanti.Close();
            verilergoster();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            SqlCommand komut = new SqlCommand("Delete from personel where id=("+id+")", baglanti);
            komut.ExecuteNonQuery();
            baglanti.Close();
            verilergoster();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            maskedTextBox1.Clear();
            textBox3.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            listView2.Items.Clear();
            baglanti.Open();
            SqlCommand komut = new SqlCommand("select * from personel where adi Like '%" + textBox1.Text + "%'", baglanti);
            SqlDataReader dr = komut.ExecuteReader();
            while (dr.Read())
            {

                ListViewItem ekle = new ListViewItem();
                ekle.Text = dr["id"].ToString();
                ekle.SubItems.Add(dr["adi"].ToString());
                ekle.SubItems.Add(dr["soyadi"].ToString());
                ekle.SubItems.Add(dr["telefon"].ToString());
                ekle.SubItems.Add(dr["yetki"].ToString());
                ekle.SubItems.Add(dr["maaş"].ToString());
                listView2.Items.Add(ekle);
            }
            baglanti.Close();
        }
    }
}
